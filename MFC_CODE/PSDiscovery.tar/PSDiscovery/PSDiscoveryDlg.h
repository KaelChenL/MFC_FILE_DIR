/*************************************************************************/
//** PSDiscoveryDlg.h : ͷ�ļ�
/*************************************************************************/
#pragma once
#ifndef _PSDISCOVERYDLG_H_
#define _PSDISCOVERYDLG_H_

#include "afxwin.h"
#include "afxcmn.h"
#include "pcap.h"
#include "PropertyDlg.h"
#include "send.h"
#include "ProcessDlg.h"
#include "recvThread.h"
#include "ParamDlg.h"

#define LIST_DEV_ID 0
#define LIST_DEV_MAC 1
#define LIST_DEV_IP 2
#define LIST_DEV_MASK 3
#define LIST_DEV_GATE 4
#define LIST_DEV_PROTYPE 5
#define LIST_DEV_NAME 6

// CPSDiscoveryDlg �Ի���
class CPSDiscoveryDlg : public CDialogEx
{
	//DECLARE_EASYSIZE
	// ����
public:
	CPSDiscoveryDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PSDISCOVERY_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	afx_msg LRESULT OnMainDlgMsg(WPARAM wParam, LPARAM lParam);

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	BOOL CPSDiscoveryDevStateCheck(int * nItem);
	DECLARE_MESSAGE_MAP()

public:
	CMenu m_Menu;
	char * cs2ca(CString str);
	CComboBox m_comboBox;
	CListCtrl m_list_dev;
	HANDLE m_DlgThreadHandle;
	u_char g_buf[1540];
	BOOL CPSDiscoveryIfDevInit();
	CRect m_rect;
	CStatusBar m_Statusbar;
	int m_iIfNum;
	CProDlg *pProDlg;
	CProcessDlg *pProcessDlg;
	BOOL m_bIsEnabeMenuStart;
	PSDP_SIGNAL_STATUS m_itemSignalStatus[256];
	unsigned int m_dev_num;
	INTERFACE_STRUCT stIfList[16];/*�õ���Ҫ��������Ϣ*/
	INTERFACE_STRUCT stCulIfDev;
	CProcessThread *m_pThread;
	POINT Old;
	CToolBar m_ToolBar;
	CParamDlg *m_pParamDlg;
	
	void OnSizing(UINT fwSide, LPRECT pRect);
	void getMac(int nItem, u_char *mac);
	void CPSDiscoveryInterfaceInit();
	void childDlgtoMainDlg(CProDlg *pDlg);
	void resize();
	void GetCurrentComboIf();
	void CPSDiscoveryListDevInit();
	void PSDiscoveryToolBarInit();
	void OnfileExport();
	void deviceSelectedCheckShow();

	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	afx_msg void OnMenuSignalOpt();
	afx_msg void OnMenuTelnet();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg void OnMenuExit();
	afx_msg void OnMenuProperty();
	afx_msg void OnMenuWeb();
	afx_msg void OnMenuPing();
	afx_msg void OnNMDblclkListDev(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnCbnSelchangeComboInterface();
	afx_msg void OnMenuSearch();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnNemuAbout();
	afx_msg void OnBnClickedButtonSearch();
	afx_msg void OnNMRClickListDev(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void ToolBarOnSearch();
	afx_msg void ToolBarOnSignal();
	afx_msg void ToolBarOnProperty();
	afx_msg void ToolBarOnWeb();
	afx_msg void ToolBarOnPing();
	afx_msg void ToolBarOnTelnet();
	afx_msg void OnPara();
	afx_msg void OnMenuPara();
	afx_msg void OnLanguageChs();
	afx_msg void OnLanguageEnglish();

	afx_msg BOOL OnToolTipsNotify(UINT id, NMHDR*pNMHDR, LRESULT*pResult);
	BOOL PreTranslateMessage(MSG * pMsg);
	virtual void OnOK();
};
#endif //_PSDISCOVERYDLG_H_