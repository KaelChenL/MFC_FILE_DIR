// StTbar.cpp : implementation file
//
// Author: Marius C. 1998 Dec 14.				 // do not remove this line
//					The code is supplied without any waranty. The code can
//					be changed or modified.
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "PSDiscovery.h"
#include "StTbar.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL m_bMenuRemoved;
/////////////////////////////////////////////////////////////////////////////
// CStTbar

CStTbar::CStTbar()
{
}
CStTbar::~CStTbar()
{
}
BEGIN_MESSAGE_MAP(CStTbar, CStatic)
	ON_WM_DESTROY()
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CStTbar message handlers
// the static is used as a place holder for miniframe wns
void CStTbar::PreSubclassWindow() 
{
	CStatic::PreSubclassWindow();
	
	RECT rt; GetWindowRect(&rt);
	GetParent()->ScreenToClient(&rt);
	// hide the place holder, no not destro it I need it to rerout the messages
	ShowWindow(SW_HIDE);
	// make it on the heap as long  CMyMiniFrm::OnNcDestroy call 'delete this' 
	// save me to map one more message
	m_minifrm = new CMyMiniFrm();
	m_minifrm->Create( AfxRegisterWndClass(0,0,0),
				L"",WS_VISIBLE|WS_CHILD,rt,GetParent()/*of placeholder*/);
#if 1
	if (!m_wndToolBar.Create(m_minifrm) ||
		!m_wndToolBar.LoadToolBar(IDC_TOOLBAR))//GetDlgCtrlID()
	{
		TRACE0("Failed to create toolbar\n");
		return ;      // fail to create
	}
#endif
	
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_BORDER_ANY | CBRS_SIZE_DYNAMIC | 0x800 | CBRS_GRIPPER);
	ToolBarInit();
	// show the window
	m_wndToolBar.ShowWindow(SW_SHOW);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_minifrm->EnableDocking(CBRS_ALIGN_ANY);
	// dock horiz if cx of static is bigger than cy
	if(rt.right-rt.left > rt.bottom-rt.top)
		m_minifrm->DockControlBar(&m_wndToolBar,AFX_IDW_DOCKBAR_TOP);	
	else
		// dock verically
		m_minifrm->DockControlBar(&m_wndToolBar,AFX_IDW_DOCKBAR_RIGHT);
	m_minifrm->RecalcLayout();
}
void CStTbar::ToolBarInit()
{
	CImageList m_ImageList;
	//����ͼ��
	m_ImageList.Create(32, 32, ILC_COLOR24 | ILC_MASK, 2, 2); //������������2,2������Ҫ�����ָ��

	
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON_SEARCH));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON_SIGNAL));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON_PROPERTY3));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON_WEB));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON_PING1));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON_TELNET));

	m_wndToolBar.GetToolBarCtrl().SetImageList(&m_ImageList);
	m_ImageList.Detach();
	m_wndToolBar.SetButtons(NULL, 6); //��6����ť
								   // ��������ÿ�����߰�ť���֣����ú�ÿ��ͼ���������ʾ��Ӧ�����֡�Ҳ���Բ�����
	m_wndToolBar.SetButtonInfo(0, ID_SEARCH, TBSTYLE_BUTTON, 0);
	m_wndToolBar.SetButtonText(0, L"SEARCH");//����

	m_wndToolBar.SetButtonInfo(1, ID_SIGNAL, TBSTYLE_BUTTON, 1);
	m_wndToolBar.SetButtonText(1, L"SIGNAL");//�ź�

	m_wndToolBar.SetButtonInfo(2, ID_PROPERTY, TBSTYLE_BUTTON, 2);
	m_wndToolBar.SetButtonText(2, L"PROPERTY");//����

	m_wndToolBar.SetButtonInfo(3, ID_WEB, TBSTYLE_BUTTON, 3);
	m_wndToolBar.SetButtonText(3, L"WEB");//��½Web

	m_wndToolBar.SetButtonInfo(4, ID_PING, TBSTYLE_BUTTON, 4);
	m_wndToolBar.SetButtonText(4, L"PING");//Ping

	m_wndToolBar.SetButtonInfo(5, ID_TELNET, TBSTYLE_BUTTON, 5);
	m_wndToolBar.SetButtonText(5, L"TELNET");//Telnet

	m_wndToolBar.SetSizes(CSize(51, 51), CSize(32, 32));
}
void CStTbar::OnDestroy() 
{
	// nothing to clean
	CStatic::OnDestroy();
}

void	CStTbar::PreTranslate(MSG* pMsg)
{
	// forward this to the toolbar
	if(/*pMsg->message >= WM_MOUSEFIRST && 
		pMsg->message <= WM_MOUSELAST &&*/
		m_wndToolBar.IsWindowVisible())
			m_wndToolBar.OnUpdateCmdUI(m_minifrm,TRUE);
}



CMyToolBar::CMyToolBar()
{
}
CMyToolBar::~CMyToolBar()
{
}
BEGIN_MESSAGE_MAP(CMyToolBar, CToolBar)
	ON_WM_WINDOWPOSCHANGED()
END_MESSAGE_MAP()


////////////////////////////////////////////////////////////////////////////
// CMyMiniFrm class implementation

CMyMiniFrm::CMyMiniFrm(){}
CMyMiniFrm::~CMyMiniFrm(){}
BEGIN_MESSAGE_MAP(CMyMiniFrm, CMiniFrameWnd)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyMiniFrm message handlers
BOOL CMyMiniFrm::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
	// pass those up in the dialog to leave the OnUpdateUI mechanism to flow
	BOOL br = GetParent()->OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
	// leave the default proc to handles the tooltip updating mechanism
	CMiniFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
	return br;	// return what the parent returns
}

void CMyToolBar::OnWindowPosChanged(WINDOWPOS* lpwndpos)
{
	CToolBar::OnWindowPosChanged(lpwndpos);
	//MessageBox(L"CMyToolBar::OnWindowPosChanged");
	// TODO: �ڴ˴�������Ϣ�����������
	TRACE1("OnWindowPosChanged %X\n ", lpwndpos->flags);
	if (IsFloating())
	{
		
		if (m_pDockBar && !m_bMenuRemoved)
		{
			CWnd* pParent = m_pDockBar->GetParent();
			if (pParent->IsKindOf(RUNTIME_CLASS(CMiniFrameWnd)))
			{
					pParent->ModifyStyle(WS_SYSMENU, 0, 0);
					m_bMenuRemoved = TRUE;
			}
		}
	}
	else if (m_bMenuRemoved) 
	{
		m_bMenuRemoved = FALSE;
	}
}
