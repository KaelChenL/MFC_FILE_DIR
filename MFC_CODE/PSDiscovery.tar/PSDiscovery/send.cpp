//PSDP.cpp
#include "stdafx.h"
#include "send.h"


int g_dataLen = 0;
u_char g_buf[1540];
pcap_if_t *g_pInetDevList = NULL;
pcap_if_t *g_pInetDevCur = NULL;
HANDLE m_ThreadHandle;			//�߳�

pcap_t *adhandle;

//u_int g_def_IP = 0xc0a80101;
CString g_def_IP_str = _T("192.168.1.1");
//u_int g_def_mask = 0xffffff00;
CString g_def_mask_str = _T("255.255.255.0");
//u_int g_def_gw = 0x00000000;
CString g_def_gw_str = _T("0.0.0.0");

//DWORD WINAPI lixsinff_CapThread(LPVOID lpParameter);
//void packet_handler(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data);

/*************************************************************************************/
//������Ϣ
/*************************************************************************************/
pcap_if_t *lixsniff_initCap(CString name, pcap_if_t *pdevHrd)
{
	int devCount = 0;
	char errbuf[1024];
	pcap_if_t *DevRet;
	pcap_if_t *alldev;
	pcap_if_t *dev;

	if (pcap_findalldevs(&alldev, errbuf) == -1)
		return NULL;
	for (dev = alldev; dev; dev = dev->next)
		devCount++;
	pdevHrd = alldev;
	for (dev = alldev; dev; dev = dev->next)
	{
		char *p = dev->name;
		while (*p != '_')
		{
			p++;
		}
		p++;

		CString pname;
		pname = p;
		int ret = StrCmpW(pname, name);
		if (ret == 0)
		{
			DevRet = &(*dev);
			return DevRet;
		}
	}

	return NULL;
}
/*************************************************************************************/
//���ͱ���
/*************************************************************************************/
void PSDiscovery_Packet_send_fun(u_char *destMac, u_char *srcMac, CString name, void *data, u_char opt)
{
	char errbuf[PCAP_ERRBUF_SIZE];
	u_char sendbuf[1540];
	u_char mac[] = { 0xC8, 0xC5, 0x0E, 0xFF, 0x00, 0x02 };//�㲥mac
	int hearderLen = 0;
	int dataLen = 0;
	int length = 0;
	int ret = 0;
	//pcap_if_t *adapter;
	pcap_if_t *pdevHdr = NULL;

	adhandle = pcap_open(g_pInetDevCur->name,          // �豸��
		65536,            // 65535��֤�ܲ��񵽲�ͬ������·���ϵ�ÿ�����ݰ���ȫ������
		PCAP_OPENFLAG_PROMISCUOUS,    // ����ģʽ
		1000,             // ��ȡ��ʱʱ��
		NULL,             // Զ�̻�����֤
		errbuf            // ���󻺳��
		);
	if (adhandle == NULL)
	{
		//m_editResult.SetWindowText(_T("Unable to open the adapter. \rIt is not supported by WinPcap"));
		/* �ͷ��豸�б� */
		pcap_freealldevs(pdevHdr);
		//MessageBox(_T("Exit!!!"));
		exit(-1);
	}
	memset(sendbuf, 0, sizeof(sendbuf));

	psdpPkt_t *psdpPkt = (psdpPkt_t*)&sendbuf[0];
	
	if (opt == DEV_COMMAND_GETINFO)
	{
		for (int loop = 0; loop < 6; loop++)
		{
			psdpPkt->hdr.DA[loop] = mac[loop];
		}
	}
	else
	{
		for (int loop = 0; loop < 6; loop++)
		{
			psdpPkt->hdr.DA[loop] = destMac[loop];
		}
	}
	memcpy(psdpPkt->hdr.SA, srcMac, MAC_LEN);
	psdpPkt->hdr.ethTypep = htons(0x88b7);
	psdpPkt->hdr.SubType = 0x8f;
	psdpPkt->hdr.OUI[0] = 0xc8;
	psdpPkt->hdr.OUI[1] = 0xc5;
	psdpPkt->hdr.OUI[2] = 0x0e;

	psdpPkt->hdr.ctrl = opt;
	if (psdpPkt->hdr.ctrl == DEV_COMMAND_SETINFO)
	{
		memcpy(&psdpPkt->msg, data, sizeof(psdpMsg_t));
		length = sizeof(*psdpPkt);
	}
	else
	{
		length = sizeof(psdpPkt->hdr);
	}

	if (pcap_sendpacket(adhandle, sendbuf, length) != 0)
	{
		AfxMessageBox(_T("error!"));
		goto END;
	}
	
	struct pcap_pkthdr *header;									  //���ݰ�ͷ
	const u_char *pkt_data = NULL, *pData = NULL;     //�������յ����ֽ�������
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();
	int lang = pApp->GetLang();												  //u_char *ppkt_data;
	int pack_num = 0;
	int pktLen = 0;
	u_char recvBuf[2048] = { 0 };
	int res = 0;
	if (psdpPkt->hdr.ctrl == DEV_COMMAND_SETINFO)
	{
		while ((res = pcap_next_ex(adhandle, &header, &pkt_data)) >= 0)//  && g_flagCtrl
		{
			if (res == 0)
			{
				ret = 0;
				break;//��ʱ
			}
			memset(recvBuf, 0, sizeof(recvBuf));
			pktLen = header->len;
			memcpy(recvBuf, pkt_data, pktLen);
			psdpPkt_t *psdpPktCheckResp = (psdpPkt_t*)recvBuf;
			if (psdpPktCheckResp->hdr.ethTypep == ntohs(PROTOCOL_PSDP_ETHTYPE) && (psdpPktCheckResp->hdr.ctrl & 0x02) == DEV_COMMAND_RESP)
			{
				if ((psdpPktCheckResp->hdr.ctrl & 0x20) == DEV_COMMAND_SETOK)
				{
					if (lang == ENGLISH)
					{
						//AfxMessageBox(_T("Modified successful��"), MB_OK |MB_ICONASTERISK);
						MessageBoxEx(NULL, _T("Modified successful��"), _T("PSDiscovery"), MB_OK | MB_ICONASTERISK, MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US));
					}
					else
					{
						//AfxMessageBox(_T("�޸ĳɹ���"), MB_OK | MB_ICONASTERISK);
						MessageBoxEx(NULL, _T("�޸ĳɹ���"), _T("PSDiscovery"), MB_OK | MB_ICONASTERISK, MAKELANGID(LANG_CHINESE, SUBLANG_CHINESE_TRADITIONAL));
					}
					break;
				}
				if ((psdpPktCheckResp->hdr.ctrl & 0x40) == DEV_COMMAND_SETFAILD)
				{
					if (lang == ENGLISH)
					{
						//AfxMessageBox(_T("Modified unsuccessful��"), MB_ICONASTERISK);
						MessageBoxEx(NULL, _T("Modified unsuccessful��"), _T("PSDiscovery"), MB_OK | MB_ICONEXCLAMATION, MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US));
					}
					else
					{
						//AfxMessageBox(_T("�޸�ʧ�ܣ�"), MB_OK | MB_ICONEXCLAMATION);
						MessageBoxEx(NULL, _T("�޸�ʧ�ܣ�"), _T("PSDiscovery"), MB_OK | MB_ICONASTERISK, MAKELANGID(LANG_CHINESE, SUBLANG_CHINESE_TRADITIONAL));
					}
					break;
				}
			}
		}
	}
	
END:
	pcap_freealldevs(pdevHdr);
	pcap_close(adhandle);
}
