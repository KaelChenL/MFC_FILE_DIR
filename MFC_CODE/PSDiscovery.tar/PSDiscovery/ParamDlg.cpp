// ParamDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSDiscovery.h"
#include "ParamDlg.h"
#include "afxdialogex.h"


// CParamDlg �Ի���

IMPLEMENT_DYNAMIC(CParamDlg, CDialogEx)

CParamDlg::CParamDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_PARA_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON4);
	
}

CParamDlg::~CParamDlg()
{
}

void CParamDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CParamDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_SAVE, &CParamDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CParamDlg ��Ϣ��������


BOOL CParamDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	SetIcon(m_hIcon, TRUE);
	SetDlgItemText(IDC_IPADDRESS_PARAM_IP,		g_def_IP_str);
	SetDlgItemText(IDC_IPADDRESS_PARAM_MASK,	g_def_mask_str);
	SetDlgItemText(IDC_IPADDRESS_PARAM_GATEWAY, g_def_gw_str);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}


void CParamDlg::OnBnClickedButton1()
{
	OnOK();
}

BOOL CParamDlg::PreTranslateMessage(MSG* pMsg)	// << ADD THIS
{
	// Reroute message to the miniframe wnd

	if (pMsg->message == WM_KEYDOWN)
	{
		switch (pMsg->wParam)
		{
			//case VK_RETURN: //�س�  
			//	return TRUE;
		case VK_ESCAPE: //ESC  
			return TRUE;
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CParamDlg::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	GetDlgItemText(IDC_IPADDRESS_PARAM_IP, g_def_IP_str);
	GetDlgItemText(IDC_IPADDRESS_PARAM_MASK, g_def_mask_str);
	GetDlgItemText(IDC_IPADDRESS_PARAM_GATEWAY, g_def_gw_str);
	CDialogEx::OnOK();
}
