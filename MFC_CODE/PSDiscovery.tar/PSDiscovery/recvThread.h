/*************************************************************************/
// recvThread.h : PROJECT_NAME Ӧ�ó������ͷ�ļ�
/*************************************************************************/

#pragma once
#ifndef _RECVTHREAD_H_
#define _RECVTHREAD_H_
#include "afxwin.h"
#include "afxcmn.h"
#include "ProcessDlg.h"
#include "pcap.h"
#include "send.h"

#define WM_PROGRESS WM_USER+100
//#define WM_PROGRESS_MAIN WM_USER+101
// CProcessThread

class CProcessThread : public CWinThread
{
	DECLARE_DYNCREATE(CProcessThread)

protected:
	CProcessThread();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CProcessThread();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	void CProcessThread::OnThreadMsg(WPARAM wParam, LPARAM lParam);
	int PSDiscovery_Packet_recv_fun(CListCtrl * m_plistCtrl, void * pInfo);
	CPSDiscoveryDlg *m_pMainDlg;
	unsigned int m_nRange;//�������ķ�Χ

protected:
	DECLARE_MESSAGE_MAP()
};

#endif //_RECVTHREAD_H_
