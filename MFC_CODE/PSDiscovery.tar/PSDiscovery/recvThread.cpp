// ProcessThread.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSDiscovery.h"
#include "recvThread.h"


volatile BOOL g_flagCtrl;
HWND m_handle;
#pragma pack(1)
// CProcessThread
//void LLC_Packet_recv_fun(CListCtrl *m_plistCtrl,void *pInfo);
IMPLEMENT_DYNCREATE(CProcessThread, CWinThread)

CProcessThread::CProcessThread()
{
}

CProcessThread::~CProcessThread()
{
}

BOOL CProcessThread::InitInstance()
{
	// TODO:    �ڴ�ִ���������̳߳�ʼ��
	//m_pMainDlg = new CPSDiscoveryDlg;

	
	//m_pProgressDlg->ShowWindow(SW_SHOW);
	return TRUE;
	
}

int CProcessThread::ExitInstance()
{
	// TODO:    �ڴ�ִ���������߳�����
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CProcessThread, CWinThread)
	ON_THREAD_MESSAGE(WM_PROGRESS, &CProcessThread::OnThreadMsg)
END_MESSAGE_MAP()

// CProcessThread ��Ϣ��������
void CProcessThread::OnThreadMsg(WPARAM wParam, LPARAM lParam)
{
	//m_handle = (HWND)wParam;
	if (!wParam && !wParam)
	{
		AfxEndThread(0);
	}
	//������Ϣ
	CListCtrl *m_plistCtrl = (CListCtrl *)wParam;
	//��ʼ���ձ���
	PSDiscovery_Packet_recv_fun(m_plistCtrl,(void *)lParam);
}
/*************************************************************************************/
//���ձ����߳�
/*************************************************************************************/
int CProcessThread::PSDiscovery_Packet_recv_fun(CListCtrl *m_plistCtrl,void *pInfo)
{
#pragma pack(1)
	//pcap_if_t *adapter;
	char errbuf[1024];
	int res;
	int ret = 1;
	int m_nRow = 0;
	int m_num = 1;
	pcap_t *adhandle;
	u_char recvBuf[2048] = { 0 };
	u_char ctrl = 0;
	int pktLen = 0;
	
	CString timestr, buf, srcMac, destMac;
	pcap_if_t *pdevHdr = NULL;
	struct pcap_pkthdr *header;									  //���ݰ�ͷ
	const u_char *pkt_data = NULL, *pData = NULL;     //�������յ����ֽ�������
													  //u_char *ppkt_data;
	int pack_num = 0;
	//struct PSDP_HDR_t *psdp_pkt = NULL;

	//struct PSDP_MSG_t * psdp_msg = NULL;

	INTERFACE_STRUCT *m_pstDevInfo;
	m_pstDevInfo = (INTERFACE_STRUCT *)pInfo;
	
	memset(errbuf, 0 ,sizeof(errbuf));
	if ((adhandle = pcap_open_live(g_pInetDevCur->name,	// �豸��
		65536,											// �������ݰ�����																					
		1,												// ����ģʽ (��0��ζ���ǻ���ģʽ)
		1000,											// ����ʱ����
		errbuf											// ������Ϣ
		)) == NULL)
	{
		pcap_freealldevs(pdevHdr);
		return 1;
	}

	while ((res = pcap_next_ex(adhandle, &header, &pkt_data)) >= 0)//  && g_flagCtrl
	{
		if (res == 0)
		{
			ret = 0;
			break;//��ʱ

		}
		if (g_flagCtrl != TRUE)
		{
			ret = 2;
			break;
		}

		if (pkt_data == NULL)
		{
			continue;
		}

		memset(recvBuf, 0, sizeof(recvBuf));
		pktLen = header->len;
		memcpy(recvBuf, pkt_data, pktLen);
		//psdp_pkt = (struct PSDP_HDR_t *)recvBuf;
		//llc_pack = (struct LLCPacket*)recvBuf;
		//if (psdp_pkt->SubType == PROTOCOL_ID_PSDP)
		psdpPkt_t *psdpPkt = (psdpPkt_t*)recvBuf;
		if (psdpPkt->hdr.ethTypep != ntohs(PROTOCOL_PSDP_ETHTYPE))
		{
			continue;
		}
		if(psdpPkt->hdr.SubType == PROTOCOL_PSDP_SUBTYPE)
		{
			psdpMsg_t *psdp_msg = &psdpPkt->msg;
			psdpHdr_t *psdp_hdr = &psdpPkt->hdr;
			//ctrl = recvBuf[18];
			int ret = 0;
			u_int m_intTmp = 0;
			//ret = memcmp((char *)(m_pstDevInfo->aucMac), (char*)(llc_pack->eth_hdr.DestMAC), 6);
			if (psdpPkt->hdr.ctrl == DEV_COMMAND_RESP)
			{
				CString bufs;
				bufs.Format(_T("%d"), m_num);
				m_nRow = m_plistCtrl->InsertItem(m_num, bufs);//������
				//MAC
				bufs.Empty();
				bufs.Format(_T("%02x-%02x-%02x-%02x-%02x-%02x"),
					psdp_hdr->SA[0],
					psdp_hdr->SA[1],
					psdp_hdr->SA[2],
					psdp_hdr->SA[3],
					psdp_hdr->SA[4],
					psdp_hdr->SA[5]);
				m_plistCtrl->SetItemText(m_nRow, 1, bufs);
				//IP
				bufs.Empty();
				m_intTmp = ntohl(psdp_msg->ipAddr);
				bufs.Format(_T("%d.%d.%d.%d"),
					(m_intTmp & 0xff000000) >> 24,
					(m_intTmp & 0xff0000) >> 16,
					(m_intTmp & 0xff00) >> 8,
					(m_intTmp & 0xff));
				//bufs.Format(_T("%x"), m_intTmp);
				m_plistCtrl->SetItemText(m_nRow, 2, bufs);
				//mask
				bufs.Empty();
				m_intTmp = ntohl(psdp_msg->mask);
				bufs.Format(_T("%d.%d.%d.%d"),
					(m_intTmp & 0xff000000) >> 24,
					(m_intTmp & 0xff0000) >> 16,
					(m_intTmp & 0xff00) >> 8,
					(m_intTmp & 0xff));
				//bufs.Format(_T("%x"), m_intTmp);
				m_plistCtrl->SetItemText(m_nRow, 3, bufs);
				//gate
				bufs.Empty();
				m_intTmp = ntohl(psdp_msg->gate);
				bufs.Format(_T("%d.%d.%d.%d"),
					(m_intTmp & 0xff000000) >> 24,
					(m_intTmp & 0xff0000) >> 16,
					(m_intTmp & 0xff00) >> 8,
					(m_intTmp & 0xff));
				//bufs.Format(_T("%x"), m_intTmp);
				m_plistCtrl->SetItemText(m_nRow, 4, bufs);
				//devtype
				bufs.Empty();
				CString Str1;
				if ((psdp_msg->devType[0]))
				{

					Str1 = psdp_msg->devType;
					bufs.Format(_T("%s"), Str1);
				}

				m_plistCtrl->SetItemText(m_nRow, 5, bufs);
				//name
				bufs.Empty();
				if ((psdp_msg->name[0]))
				{
					Str1 = psdp_msg->name;
					bufs.Format(_T("%s"), Str1);
				}

				m_plistCtrl->SetItemText(m_nRow, 6, bufs);

				//PostMessageA(AfxGetApp()->m_pMainWnd->m_hWnd, WM_PROGRESS_MAIN, 0, 0);//(LPARAM)&m_stDevInfo
				m_num++;
		}

			
		}
	}
	pcap_freealldevs(pdevHdr);
	pcap_close(adhandle);
	return ret;
}
