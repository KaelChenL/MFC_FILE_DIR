/*************************************************************************/
//paramDlg.h
/*************************************************************************/
#pragma once

#include"send.h"
// CParamDlg �Ի���

class CParamDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CParamDlg)
protected:
	HICON m_hIcon;
public:
	CParamDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CParamDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_PARA };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButton1();
	virtual void OnOK();
	BOOL CParamDlg::PreTranslateMessage(MSG* pMsg);
};
