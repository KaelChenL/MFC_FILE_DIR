/*************************************************************************/
// send.h : PROJECT_NAME Ӧ�ó������ͷ�ļ�
/*************************************************************************/

#ifndef _SEND_H_
#define _SEND_H_


#include "pcap.h"
#include "afxwin.h"
#include "afxcmn.h"
#include "PSDiscovery.h"
#include "PropertyDlg.h"
#include "stdafx.h"

#pragma pack(1)
#ifndef __packed
#define __packed __attrubte__((packed))
#endif
#define MAC_LEN 6

#define DEV_COMMAND_GETINFO			0x01
#define DEV_COMMAND_RESP			0x02
#define DEV_COMMAND_SETINFO			0x04
#define DEV_COMMAND_SIGNAL_OPEN		0x08
#define DEV_COMMAND_SIGNAL_CLOSE	0x10
#define DEV_COMMAND_SETOK			0x20
#define DEV_COMMAND_SETFAILD		0x40


typedef struct
{
	CString aucName;
	CString adapterName;
	CString aucDescription;
	unsigned char aucMac[6];
	CString auiIp[256];
	unsigned int uiIpAddrNum;
	pcap_if_t *dev;
}INTERFACE_STRUCT;

#pragma pack(push)
#pragma pack(1)
typedef struct 
{
	u_char DA[6];
	u_char SA[6];
	u_short ethTypep;
	u_char OUI[3];
	u_char SubType;
	u_char ctrl;//ctrl
}psdpHdr_t ;

typedef struct 
{
	u_long ipAddr;
	u_long mask;
	u_long gate;
	u_char name[32 + 1];
	u_char devType[32 + 1];
}psdpMsg_t ;

typedef struct 
{
	psdpHdr_t hdr;
	psdpMsg_t msg;
}psdpPkt_t ;
#pragma pack(pop) 

typedef struct
{
	unsigned int item;
	unsigned char status;
}PSDP_SIGNAL_STATUS;

extern volatile BOOL g_flagCtrl;
extern pcap_if_t *g_pInetDevList;
extern pcap_if_t *g_pInetDevCur;

#define PROTOCOL_PSDP_SUBTYPE 0x8f
#define PROTOCOL_PSDP_ETHTYPE 0x88b7

pcap_if_t *lixsniff_initCap(CString name, pcap_if_t *pdevHrd);
extern void PSDiscovery_Packet_send_fun(u_char *destMac, u_char *srcMac, CString name, void *data, u_char flag);


extern u_int g_def_IP;
extern CString g_def_IP_str;
extern u_int g_def_mask;
extern CString g_def_mask_str;
extern u_int g_def_gw;
extern CString g_def_gw_str;

#endif//_SEND_H_
