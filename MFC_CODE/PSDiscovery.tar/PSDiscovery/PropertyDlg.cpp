// ProDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSDiscovery.h"
#include "PropertyDlg.h"
#include "afxdialogex.h"
#include "send.h"


//void packet_handler(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data);
//DWORD WINAPI lixsinff_CapThread(LPVOID lpParameter);

//#define PRO_DEFAULT_IP _T("192.168.0.1")
//#define PRO_DEFAULT_MASK _T("255.255.255.0")
//#define PRO_DEFAULT_GATE _T("0.0.0.0")
// CProDlg �Ի���

IMPLEMENT_DYNAMIC(CProDlg, CDialogEx)

CProDlg::CProDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_PRO_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON5);
}

CProDlg::~CProDlg()
{
}

void CProDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CProDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_IP,		&CProDlg::OnBnClickedButtonIp		)
	ON_BN_CLICKED(IDC_BUTTON_MASK,		&CProDlg::OnBnClickedButtonMask		)
	ON_BN_CLICKED(IDC_BUTTON_GATE,		&CProDlg::OnBnClickedButtonGate		)
	ON_BN_CLICKED(IDC_BUTTON_SAVE,		&CProDlg::OnBnClickedButtonSave		)
	ON_BN_CLICKED(IDC_BUTTON_OK,		&CProDlg::OnBnClickedButtonOk		)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL,	&CProDlg::OnBnClickedButtonCancel	)
END_MESSAGE_MAP()

void CProDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// CProDlg ��Ϣ��������
BOOL CProDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	MultiStatus = false;
	SetIcon(m_hIcon, TRUE);
	SetDlgItemText(IDC_EDIT_MAC,		m_stdev_node.Mac	);
	SetDlgItemText(IDC_EDIT_NAME,		m_stdev_node.Name	);
	SetDlgItemText(IDC_IPADDRESS_IP,	m_stdev_node.Ip		);
	SetDlgItemText(IDC_IPADDRESS_MASK,	m_stdev_node.Mask	);
	SetDlgItemText(IDC_IPADDRESS_GATE,	m_stdev_node.Gate	);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}

void CProDlg::OnBnClickedButtonIp()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SetDlgItemText(IDC_IPADDRESS_IP, g_def_IP_str);
}


void CProDlg::OnBnClickedButtonMask()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SetDlgItemText(IDC_IPADDRESS_MASK, g_def_mask_str);
}


void CProDlg::OnBnClickedButtonGate()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SetDlgItemText(IDC_IPADDRESS_GATE, g_def_gw_str);
}


void CProDlg::OnBnClickedButtonSave()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	GetDlgItemText(IDC_IPADDRESS_IP,	g_def_IP_str	);
	GetDlgItemText(IDC_IPADDRESS_MASK,	g_def_mask_str	);
	GetDlgItemText(IDC_IPADDRESS_GATE,	g_def_gw_str	);
	//MessageBox(g_def_IP_str + L"/r/n" + g_def_mask_str + L"/r/n" + g_def_gw_str);
}

void CProDlg::mainDlgtoThisdlg(CPSDiscoveryDlg *Dlg)
{
}

char * cs2ca(CString str)
{
	char *ptr;
#ifdef _UNICODE
	LONG len;
	len = WideCharToMultiByte(CP_ACP, 0, str, -1, NULL, 0, NULL, NULL);
	ptr = new char[len + 1];
	memset(ptr, 0, len + 1);
	WideCharToMultiByte(CP_ACP, 0, str, -1, ptr, len + 1, NULL, NULL);
#else
	ptr = new char[str.GetAllocLength() + 1];
	sprintf(ptr, _T("%s"), str);
#endif
	return ptr;
}

void CProDlg::getMac(u_char *mac)
{
	CString strBuf;
	char *p = NULL;
	int i = 0;
	GetDlgItemText(IDC_EDIT_MAC, strBuf);
	p = cs2ca(strBuf);

	while (*p)
	{
		if (*p == '-')
		{
			p++;
			continue;
		}

		if ((*p >= 'A' && *p <= 'F'))
		{
			*p = *p - 'A' + 10;
		}
		else if ((*p >= 'a' && *p <= 'f'))
		{
			*p = *p - 'a' + 10;
		}
		else if (*p >= '0' && *p <= '9')
		{
			*p = *p - '0';
		}
		mac[i] = (*p) << 4;
		p++;
		if ((*p >= 'A' && *p <= 'F'))
		{
			*p = *p - 'A' + 10;
		}
		else if ((*p >= 'a' && *p <= 'f'))
		{
			*p = *p - 'a' + 10;
		}
		else if (*p >= '0' && *p <= '9')
		{
			*p = *p - '0';
		}
		mac[i] |= (*p) & 0x0f;
		p++;
		i++;
	}
	m_stdev_node.Mac = strBuf;
}

void CProDlg::getIp(u_int *ip)
{
	CString strBuf;
	char *p = NULL;
	int i = 0;
	//char tmp[32];
	GetDlgItemText(IDC_IPADDRESS_IP, strBuf);
	p = cs2ca(strBuf);

	inet_pton(AF_INET, p, (void*)ip);
	//*ip = inet_addr("127.0.0.1");
	m_stdev_node.Ip = strBuf;
}

void CProDlg::getMask(u_int *mask)
{
	CString strBuf;
	char *p = NULL;
	int i = 0;
	//char tmp[32];
	GetDlgItemText(IDC_IPADDRESS_MASK, strBuf);
	p = cs2ca(strBuf);

	inet_pton(AF_INET, p, (void*)mask);
	//*ip = inet_addr("127.0.0.1");
	m_stdev_node.Mask = strBuf;
}

void CProDlg::getGate(u_int *gate)
{
	CString strBuf;
	char *p = NULL;
	int i = 0;
	//char tmp[32];
	GetDlgItemText(IDC_IPADDRESS_GATE, strBuf);
	p = cs2ca(strBuf);

	inet_pton(AF_INET, p, (void*)gate);
	//*ip = inet_addr("127.0.0.1");
	m_stdev_node.Gate = strBuf;
}

void CProDlg::OnBnClickedButtonOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	u_char sendbuf[1024];
	u_char destMac[6] = {0};
	llcMsg_t *llc_msg = (llcMsg_t *)sendbuf;
	u_int ip;
	u_int mask;
	u_int gate;
	//u_char name[64];
	CString strBuf;
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();
	int lang = pApp->GetLang();

	memset(sendbuf, 0, 1024);
	
	getMac(destMac);
	getIp(&ip);
	llc_msg->ipAddr = ip;
	getMask(&mask);
	llc_msg->mask = mask;
	getGate(&gate);
	llc_msg->gate = gate;

	GetDlgItemText(IDC_EDIT_NAME, strBuf);
	char *p = cs2ca(strBuf);
	memcpy(llc_msg->name, p, strlen(p));

	m_stdev_node.Name = strBuf;
	//�򸸶Ի�����WM_PROGRESS_MAIN��Ϣ
	PostMessageA(AfxGetApp()->m_pMainWnd->m_hWnd, 
				WM_PROGRESS_MAIN, 
				(WPARAM)&m_stdev_node, 
				(LPARAM)0
	);
	PSDiscovery_Packet_send_fun(destMac, stCulIfDev.aucMac, stCulIfDev.adapterName, sendbuf, DEV_COMMAND_SETINFO);
	OnCancel();
}

void CProDlg::OnBnClickedButtonCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnCancel();
}

void CProDlg::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	GetDlgItem(IDC_BUTTON_OK)->SetFocus();
	OnBnClickedButtonOk();
	//CDialogEx::OnOK();
}

BOOL CProDlg::PreTranslateMessage(MSG* pMsg)	// << ADD THIS
{
	// Reroute message to the miniframe wnd

	if (pMsg->message == WM_KEYDOWN)
	{
		switch (pMsg->wParam)
		{
		//case VK_RETURN: //�س�  
		//	return TRUE;
		case VK_ESCAPE: //ESC  
			return TRUE;
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}