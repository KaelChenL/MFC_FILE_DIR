/*************************************************************************/
//proprertyDlg.h
/*************************************************************************/
#ifndef _PRODLG_H_
#define _PRODLG_H_
#pragma once

#include "pcap.h"
#include "send.h"
// CProDlg �Ի���
#define WM_PROGRESS_MAIN WM_USER+101
typedef struct
{
	CString aucName;
	CString adapterName;
	CString aucDescription;
	unsigned char aucMac[6];
	CString auiIp[256];
	unsigned int uiIpAddrNum;
}DEV_STRUCT;

struct llcMsg_t
{
	u_int ipAddr;
	u_int mask;
	u_int gate;
	u_char name[32+1];
	u_char devType[32+1];
};
typedef struct
{
	int id;
	CString Mac;
	CString Ip;
	CString Mask;
	CString Gate;
	CString Product;
	CString Name;
}DEV_LIST_NODE;

class CProDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CProDlg)
	friend class CPSDiscoveryDlg;
protected:
	HICON m_hIcon;
public:
	CProDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CProDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PRO_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	pcap_t *adhandle;
	DEV_STRUCT stCulIfDev;
	DEV_LIST_NODE m_stdev_node;
	BOOL MultiStatus;
	void OnSysCommand(UINT nID, LPARAM lParam);
	BOOL OnInitDialog();
	void OnBnClickedButtonIp();
	afx_msg void OnBnClickedButtonMask();
	afx_msg void OnBnClickedButtonGate();
	afx_msg void OnBnClickedButtonSave();
	void mainDlgtoThisdlg(CPSDiscoveryDlg * Dlg);
	void getMac(u_char * mac);
	void getIp(u_int * ip);
	void getMask(u_int * mask);
	void getGate(u_int * gate);
	void OnBnClickedButtonOk();
	afx_msg void OnBnClickedButtonCancel();
	BOOL CProDlg::PreTranslateMessage(MSG* pMsg);
	virtual void OnOK();
};
#endif //_PRODLG_H_