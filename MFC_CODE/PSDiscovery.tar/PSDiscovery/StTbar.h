#if !defined(AFX_STTBAR_H__ACA9297E_8F62_11D2_822A_00600815B1D4__INCLUDED_)
#define AFX_STTBAR_H__ACA9297E_8F62_11D2_822A_00600815B1D4__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CMyToolBar;
class CMyMiniFrm;
class CStTbar;
// StTbar.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CStTbar window
class CMyMiniFrm : public CMiniFrameWnd
{

public:
	CMyMiniFrm();           // protected constructor used by dynamic creation

public:
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);


protected:
	virtual ~CMyMiniFrm();

	DECLARE_MESSAGE_MAP()
public:

};




class CMyToolBar : public CToolBar
{
	//	DECLARE_DYNCREATE(CMyMiniFrm)
public:
	CMyToolBar();           // protected constructor used by dynamic creation

public:
	virtual ~CMyToolBar();

	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnWindowPosChanged(WINDOWPOS* lpwndpos);
};

/*
class CStTbar : public CStatic
*/
class CStTbar : public CStatic
{
// Construction
public:
	CStTbar();

protected:
	virtual void PreSubclassWindow();
	void ToolBarInit();
	
public:
	virtual ~CStTbar();

	// Generated message map functions
protected:
	afx_msg void OnDestroy();
	DECLARE_MESSAGE_MAP()
	CMyToolBar		m_wndToolBar;
	CMyMiniFrm*		m_minifrm;
public:
	void	PreTranslate(MSG* pMsg);
	CMyToolBar&	GetTBar(){return m_wndToolBar;};

};
#endif // !defined(AFX_STTBAR_H__ACA9297E_8F62_11D2_822A_00600815B1D4__INCLUDED_)