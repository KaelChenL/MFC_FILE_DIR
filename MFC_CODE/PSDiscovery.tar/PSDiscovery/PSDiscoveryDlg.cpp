
// PSDiscoveryDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSDiscovery.h"
#include "PSDiscoveryDlg.h"
#include "afxdialogex.h"
//#include "easysize.h"


volatile int m_bRun = 10;//��������ʱ����
// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnStnClickedPictrueCtrl();//���ͼƬ��Ӧ�¼�
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);//�ı������״
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
	ON_WM_TIMER()
	ON_STN_CLICKED(IDC_PICTRUE_CTRL, &CAboutDlg::OnStnClickedPictrueCtrl)
	ON_WM_SETCURSOR()
END_MESSAGE_MAP()

// CPSDiscoveryDlg �Ի���
CPSDiscoveryDlg::CPSDiscoveryDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_PSDISCOVERY_DIALOG, pParent)
{
	//m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON_PS3);
}

void CPSDiscoveryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_INTERFACE, m_comboBox);
	DDX_Control(pDX, IDC_LIST_DEV, m_list_dev);
}

BEGIN_MESSAGE_MAP(CPSDiscoveryDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_GETMINMAXINFO()
	ON_WM_SIZE()
	ON_WM_INITMENUPOPUP()
	ON_WM_TIMER()
	ON_COMMAND		(ID_MENU_SEARCH,			&CPSDiscoveryDlg::OnMenuSearch				)
	ON_COMMAND		(ID_NEMU_ABOUT,				&CPSDiscoveryDlg::OnNemuAbout				)
	ON_COMMAND		(ID_MENU_EXIT,				&CPSDiscoveryDlg::OnMenuExit				)
	ON_COMMAND		(ID_MENU_PROPERTY,			&CPSDiscoveryDlg::OnMenuProperty			)
	ON_COMMAND		(ID_MENU_WEB,				&CPSDiscoveryDlg::OnMenuWeb					)
	ON_COMMAND		(ID_MENU_PING,				&CPSDiscoveryDlg::OnMenuPing				)
	ON_COMMAND		(IDR_MENU_SIGNAL,			&CPSDiscoveryDlg::OnMenuSignalOpt			)
	ON_COMMAND		(ID_MENU_TELNET,			&CPSDiscoveryDlg::OnMenuTelnet				)
	ON_COMMAND		(ID_SEARCH,					&CPSDiscoveryDlg::ToolBarOnSearch			)
	ON_COMMAND		(ID_SIGNAL,					&CPSDiscoveryDlg::ToolBarOnSignal			)
	ON_COMMAND		(ID_PROPERTY,				&CPSDiscoveryDlg::ToolBarOnProperty			)
	ON_COMMAND		(ID_WEB,					&CPSDiscoveryDlg::ToolBarOnWeb				)
	ON_COMMAND		(ID_PING,					&CPSDiscoveryDlg::ToolBarOnPing				)
	ON_COMMAND		(ID_TELNET,					&CPSDiscoveryDlg::ToolBarOnTelnet			)
	ON_COMMAND		(ID_PARA,					&CPSDiscoveryDlg::OnPara					)
	ON_COMMAND		(ID_MENU_PARA,				&CPSDiscoveryDlg::OnMenuPara				)
	ON_BN_CLICKED	(IDC_BUTTON_SEARCH,			&CPSDiscoveryDlg::OnBnClickedButtonSearch	)
	ON_NOTIFY		(NM_RCLICK, IDC_LIST_DEV,	&CPSDiscoveryDlg::OnNMRClickListDev			)
	ON_NOTIFY		(NM_DBLCLK, IDC_LIST_DEV,	&CPSDiscoveryDlg::OnNMDblclkListDev			)
	ON_NOTIFY_EX	(TTN_NEEDTEXT, 0,			&CPSDiscoveryDlg::OnToolTipsNotify			)
	ON_CBN_SELCHANGE(IDC_COMBO_INTERFACE,		&CPSDiscoveryDlg::OnCbnSelchangeComboInterface)
	ON_MESSAGE		(WM_PROGRESS_MAIN,			&CPSDiscoveryDlg::OnMainDlgMsg				)//�û�ע�����Ϣ���������������̷߳�������Ϣ
	ON_COMMAND		(ID_LANGUAGE_CHS,			&CPSDiscoveryDlg::OnLanguageChs				)
	ON_COMMAND		(ID_LANGUAGE_ENGLISH,		&CPSDiscoveryDlg::OnLanguageEnglish			)
	ON_COMMAND		(ID_FILE_EXPORT,			&CPSDiscoveryDlg::OnfileExport				)
END_MESSAGE_MAP()


// CPSDiscoveryDlg ��Ϣ��������
//���Ի������WM_PROGRESS_MAIN��Ϣ
LRESULT CPSDiscoveryDlg::OnMainDlgMsg(WPARAM wParam, LPARAM lParam)
{
	char *p = (char*)wParam;
	if (memcmp(p, "stop_Timer", sizeof("stop_Timer")) == 0)
	{
		m_bRun = 10;
		KillTimer(1);
		return 1;
	}

	DEV_LIST_NODE *m_list_node = (DEV_LIST_NODE*)wParam;
	int id = m_list_node->id;
	
	m_list_dev.SetItemText(id, LIST_DEV_IP,		m_list_node->Ip);
	m_list_dev.SetItemText(id, LIST_DEV_MASK,	m_list_node->Mask);
	m_list_dev.SetItemText(id, LIST_DEV_GATE,	m_list_node->Gate);
	m_list_dev.SetItemText(id, LIST_DEV_NAME,	m_list_node->Name);

	return 1;
}
BOOL CPSDiscoveryDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ  ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
/*************************************************************************************/
//һ��Ϊ�Զ����ʼ��
/*************************************************************************************/
	//��ʼ���˵���
	m_Menu.LoadMenu(IDR_MENU);
	SetMenu(&m_Menu);
	
	//��ʼ���豸��Ϣ�Ի���
	pProDlg = new CProDlg;

	/*��ʼ��������*/
	PSDiscoveryToolBarInit();

	/*��ʼ���豸�б�*/
	CPSDiscoveryListDevInit();

	/*��ʼ���ӿ��б�*/
	CPSDiscoveryInterfaceInit();

	//��ʼ��ץ���̵߳Ŀ��Ʊ�־
	//g_flagCtrl = TRUE;
	m_pThread = (CProcessThread*)AfxBeginThread(RUNTIME_CLASS(CProcessThread));//��������,���ý����˳���־

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CPSDiscoveryDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ  ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CPSDiscoveryDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CPSDiscoveryDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
/*************************************************************************************/
//list���Ƿ���ѡ����
/*************************************************************************************/
BOOL CPSDiscoveryDlg::CPSDiscoveryDevStateCheck(int *nItem)
{
	for (int i = 0; i < m_list_dev.GetItemCount(); i++)
	{
		if (m_list_dev.GetItemState(i, LVIS_SELECTED) == LVIS_SELECTED)
		{
			*nItem = i;
			return true;
		}
	}
	return false;                                                                      
}
/*************************************************************************************/
//�˵���-->�ļ�-->�˳�
/*************************************************************************************/
void CPSDiscoveryDlg::OnMenuExit()
{
	// TODO: �ڴ�����������������
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();
	int lang = pApp->GetLang();
	if (lang == CHINESE)
	{
		if(MessageBoxEx(this->GetSafeHwnd(), _T("ȷ��Ҫ�˳���"), _T("PSDiscovery"), MB_OKCANCEL 
			| MB_ICONASTERISK, MAKELANGID(LANG_CHINESE, SUBLANG_CHINESE_TRADITIONAL)) == IDOK)
		{
			OnOK();
		}
	}
	else
	{
		if (MessageBoxEx(this->GetSafeHwnd(), _T("Sure to exit?"), _T("PSDiscovery"), MB_OKCANCEL 
			| MB_ICONASTERISK, MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US)) == IDOK)
		{
			OnOK();
		}
	}
	
}
/*************************************************************************************/
//change from CString to char*
/*************************************************************************************/
char * CPSDiscoveryDlg::cs2ca(CString str)
{
	char *ptr;
#ifdef _UNICODE
	LONG len;
	len = WideCharToMultiByte(CP_ACP, 0, str, -1, NULL, 0, NULL, NULL);
	ptr = new char[len + 1];
	memset(ptr, 0, len + 1);
	WideCharToMultiByte(CP_ACP, 0, str, -1, ptr, len + 1, NULL, NULL);
#else
	ptr = new char[str.GetAllocLength() + 1];
	sprintf(ptr, _T("%s"), str);
#endif
	return ptr;
}
/*************************************************************************************/
//get the char mac
/*************************************************************************************/
void CPSDiscoveryDlg::getMac(int nItem, u_char *mac)
{
	CString strBuf;
	char *p = NULL;
	int i = 0;
	strBuf = m_list_dev.GetItemText(nItem, LIST_DEV_MAC);
	p = cs2ca(strBuf);

	while (*p)
	{
		if (*p == '-')
		{
			p++;
			continue;
		}
	
		if ((*p >= 'A' && *p <= 'F'))
		{
			*p = *p - 'A' + 10;
		}
		else if((*p >= 'a' && *p <= 'f'))
		{
			*p = *p - 'a' + 10;
		}
		else if (*p >= '0' && *p <= '9')
		{
			*p = *p - '0';
		}
		mac[i] = (*p ) << 4;
		p++;
		if ((*p >= 'A' && *p <= 'F'))
		{
			*p = *p - 'A' + 10;
		}
		else if ((*p >= 'a' && *p <= 'f'))
		{
			*p = *p - 'a' + 10;
		}
		else if (*p >= '0' && *p <= '9')
		{
			*p = *p - '0';
		}
		mac[i] |= (*p) & 0x0f;
		p++;
		i++;
	}

}
/*************************************************************************************/
//check device selected status
/*************************************************************************************/
void CPSDiscoveryDlg::deviceSelectedCheckShow()
{
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();
	int lang = pApp->GetLang();
	if (lang == CHINESE)
	{
		MessageBoxEx(this->GetSafeHwnd(), _T("δѡ���κ��"), _T("PSDiscovery"), MB_OK |
			MB_ICONEXCLAMATION, MAKELANGID(LANG_CHINESE, SUBLANG_CHINESE_TRADITIONAL));
	}
	else
	{
		MessageBoxEx(this->GetSafeHwnd(), _T("No device selected��"), _T("PSDiscovery"), MB_OK |
			MB_ICONEXCLAMATION, MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US));
	}
}
/*************************************************************************************/
//�˵���-->�༭-->�ź�
/*************************************************************************************/
void CPSDiscoveryDlg::OnMenuSignalOpt()
{
	// TODO: �ڴ�����������������
	
	int nItem = 0;
	int ret;
	u_char sendBuf[1024];
	u_char mac[6] = {0};
	u_char signalOpt = FALSE;
	u_char m_status = 0;
	PSDP_SIGNAL_STATUS *p = m_itemSignalStatus;
	PSDP_SIGNAL_STATUS *q = m_itemSignalStatus;

	ret = CPSDiscoveryDevStateCheck(&nItem);
	if (!ret)
	{
		//MessageBox(_T("     δѡ���κ��"));
		//m_pWarningDlg->DoModal();
		deviceSelectedCheckShow();
	}
	else
	{
		//��ȡ��ǰ������
		GetCurrentComboIf();
		getMac(nItem, mac);
		memset(sendBuf, 0, 1024);

		while (q->item)
		{
			if (nItem + 1 == q->item)
			{
				m_status = q->status;
				break;
			}
			q++;
		}
		//m_signalEnable = !m_signalEnable;
		if (m_status == 0x00 || m_status == DEV_COMMAND_SIGNAL_CLOSE)
		{
			signalOpt = DEV_COMMAND_SIGNAL_OPEN;
		}
		else if(m_status == DEV_COMMAND_SIGNAL_OPEN)
		{
			signalOpt = DEV_COMMAND_SIGNAL_CLOSE;
		}
		PSDiscovery_Packet_send_fun(mac, stCulIfDev.aucMac, stCulIfDev.adapterName, sendBuf, signalOpt);
		while (p->item)
		{
			if (nItem+1 == p->item)
			{
				p->status = signalOpt;
				break;
			}
			p++;
		}
		if (!p->item)
		{
			p->item = nItem+1;
			p->status = signalOpt;
		}
	}
}
/*************************************************************************************/
//�˵���-->�༭-->�豸��Ϣ
/*************************************************************************************/
void CPSDiscoveryDlg::OnMenuProperty()
{
	// TODO: �ڴ�����������������
	int nItem = 0;
	int ret;
	//��ȡ˫������
	ret = CPSDiscoveryDevStateCheck(&nItem);
	if (!ret)
	{
		deviceSelectedCheckShow();
	}
	else
	{
		pProDlg->m_stdev_node.id = nItem;
		CString strBuf;
		//��ȡ��ǰ�е���Ϣ
		strBuf = m_list_dev.GetItemText(nItem, LIST_DEV_MAC);
		//���ݸ�����dialog
		pProDlg->m_stdev_node.Mac.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, LIST_DEV_NAME);
		pProDlg->m_stdev_node.Name.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, LIST_DEV_IP);
		pProDlg->m_stdev_node.Ip.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, LIST_DEV_MASK);
		pProDlg->m_stdev_node.Mask.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, LIST_DEV_GATE);
		pProDlg->m_stdev_node.Gate.Format(_T("%s"), strBuf);
		pProDlg->DoModal();

		GetCurrentComboIf();
	}

}
/*************************************************************************************/
//�˵���-->�༭-->��¼WEB
/*************************************************************************************/
void CPSDiscoveryDlg::OnMenuWeb()
{
	// TODO: �ڴ�����������������
	int nItem = 0;
	int ret;
	ret = CPSDiscoveryDevStateCheck(&nItem);
	if (!ret)
	{
		deviceSelectedCheckShow();
	}
	else
	{
		CString strBuf(_T("http://"));
		strBuf += m_list_dev.GetItemText(nItem, LIST_DEV_IP);
		ShellExecute(NULL, _T("open"), strBuf, NULL, NULL, SW_SHOWNORMAL);
	}
}
/*************************************************************************************/
//�ж�ϵͳ�Ƿ�Ϊ64λ
/*************************************************************************************/
BOOL is64System()
{
	typedef BOOL(WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL);
	LPFN_ISWOW64PROCESS fnIsWow64Process;
	BOOL bIsWow64 = FALSE;
	fnIsWow64Process = (LPFN_ISWOW64PROCESS)GetProcAddress(GetModuleHandle(_T("kernel32")), "IsWow64Process");
	if (NULL != fnIsWow64Process)
	{
		fnIsWow64Process(GetCurrentProcess(), &bIsWow64);
	}
	return bIsWow64;
}
/*************************************************************************************/
//�˵���-->�༭-->Ping
/*************************************************************************************/
void CPSDiscoveryDlg::OnMenuPing()
{
	// TODO: �ڴ�����������������
	int nItem = 0;
	int ret;
	ret = CPSDiscoveryDevStateCheck(&nItem);
	if (!ret)
	{
		deviceSelectedCheckShow();
	}
	else
	{
		CString strBuf;
		strBuf = m_list_dev.GetItemText(nItem, LIST_DEV_IP);
		strBuf += _T(" -t");
		ShellExecute(NULL, _T("open"), _T("ping"), strBuf, NULL, SW_SHOW);
	}
}
/*************************************************************************************/
//�˵���-->�༭-->Telnet
/*************************************************************************************/
void CPSDiscoveryDlg::OnMenuTelnet()
{
	// TODO: �ڴ�����������������
	int nItem = 0;
	int ret;
	ret = CPSDiscoveryDevStateCheck(&nItem);
	if (!ret)
	{
		deviceSelectedCheckShow();
	}
	else
	{
		if (is64System()) //����Ҫ�ж�ʱ����������ĺ�������Ϊ64λʱ����ú�������True�����򷵻�False������telnet�ĵ�ַΪ192.168.1.110
		{
			CString strBuf;
			strBuf = _T("/K %windir%\\sysnative\\telnet ");
			strBuf += m_list_dev.GetItemText(nItem, LIST_DEV_IP);
			ShellExecute(NULL, NULL, L"cmd.exe", strBuf, NULL,/*SW_NORMAL*/SW_SHOWNORMAL);
		}
		else    //32λʱ
		{
			CString strBuf;
			strBuf = _T("/K telnet ");
			strBuf += m_list_dev.GetItemText(nItem, LIST_DEV_IP);
			ShellExecute(NULL, NULL, _T("cmd.exe"), strBuf, NULL,/*SW_NORMAL*/SW_SHOWNORMAL);
		}
	}
}

/*************************************************************************************/
//�˵���-->�ļ�-->Discovery
/*************************************************************************************/
void CPSDiscoveryDlg::OnMenuSearch()
{
	// TODO: �ڴ�����������������
	u_char sendbuf[1024];
	//��ȡ��ǰ������
	GetCurrentComboIf();

	//ÿ������ǰ���list
	m_list_dev.DeleteAllItems();

	memset(m_itemSignalStatus, 0, sizeof(PSDP_SIGNAL_STATUS) * 256);

	//����������
	pProcessDlg = new CProcessDlg;

	//����ץ������
	//m_pThread = (CProcessThread*)AfxBeginThread(RUNTIME_CLASS(CProcessThread));//��������

	//���ý����˳���־
	g_flagCtrl = TRUE;

	//���ݲ�����ץ������
	m_pThread->PostThreadMessage(WM_PROGRESS, (WPARAM)&this->m_list_dev, (LPARAM)&this->stCulIfDev);//���ݲ���

	SetTimer(1, 300, NULL);
	//���͹㲥����
	memset(sendbuf, 0, 1024);
	PSDiscovery_Packet_send_fun(NULL, stCulIfDev.aucMac, stCulIfDev.adapterName, sendbuf, DEV_COMMAND_GETINFO);
	//��ʾ������
	pProcessDlg->DoModal();
}

/*************************************************************************************/
//Ĭ�ϲ����Ի���
/*************************************************************************************/
void CPSDiscoveryDlg::OnMenuPara()
{
	// TODO: �ڴ�����������������
	//MessageBox(L"param");
	m_pParamDlg = new CParamDlg;
	m_pParamDlg->DoModal();
}

/*************************************************************************************/
//�豸list��ʼ��
/*************************************************************************************/
void CPSDiscoveryDlg::CPSDiscoveryListDevInit()
{
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();
	int lang = pApp->GetLang();
	//m_list_dev.InsertColumn(0, "ID", LVCFMT_LEFT, 40);//������
	//m_list_dev.InsertColumn(1, "NAME", LVCFMT_LEFT, 50);
	//int nRow = m_list_dev.InsertItem(0, "11");//������
	//m_list_dev.SetItemText(nRow, 1, "jacky");//��������
	//DWORD dwStyle = m_list_dev.GetStyle();
	//dwStyle |= LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT | LVS_SHOWSELALWAYS;
	//m_list_dev.SetExtendedStyle(dwStyle);
	m_list_dev.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	//m_list_dev.SetBkColor(RGB(76, 85, 118));
	//m_list_dev.SetTextColor(RGB(222, 222, 222));
	//m_list_dev.SetTextColor(RGB(0, 199, 140));                  //��ʾ�������ɫ
		
	if (lang == ENGLISH)
	{
		m_list_dev.InsertColumn(LIST_DEV_ID,		_T("ID"),		LVCFMT_LEFT, 40,  -1);
		m_list_dev.InsertColumn(LIST_DEV_MAC,		_T("Mac"),		LVCFMT_LEFT, 120, -1);
		m_list_dev.InsertColumn(LIST_DEV_IP,		_T("IP"),		LVCFMT_LEFT, 110, -1);
		m_list_dev.InsertColumn(LIST_DEV_MASK,		_T("Mask"),		LVCFMT_LEFT, 110, -1);
		m_list_dev.InsertColumn(LIST_DEV_GATE,		_T("Gateway"),	LVCFMT_LEFT, 110, -1);
		m_list_dev.InsertColumn(LIST_DEV_PROTYPE,	_T("Product"),	LVCFMT_LEFT, 110, -1);
		m_list_dev.InsertColumn(LIST_DEV_NAME,		_T("Name"),		LVCFMT_LEFT, 150, -1);
	}
	
	if (lang == CHINESE)
	{
		m_list_dev.InsertColumn(LIST_DEV_ID,		_T("ID"),		LVCFMT_LEFT, 40,  -1);
		m_list_dev.InsertColumn(LIST_DEV_MAC,		_T("Mac��ַ"),	LVCFMT_LEFT, 120, -1);
		m_list_dev.InsertColumn(LIST_DEV_IP,		_T("IP��ַ"),	LVCFMT_LEFT, 110, -1);
		m_list_dev.InsertColumn(LIST_DEV_MASK,		_T("��������"), LVCFMT_LEFT, 110, -1);
		m_list_dev.InsertColumn(LIST_DEV_GATE,		_T("ȱʡ����"), LVCFMT_LEFT, 110, -1);
		m_list_dev.InsertColumn(LIST_DEV_PROTYPE,	_T("��Ʒ"),		LVCFMT_LEFT, 110, -1);
		m_list_dev.InsertColumn(LIST_DEV_NAME,		_T("����"),		LVCFMT_LEFT, 150, -1);
	}
}
/*************************************************************************************/
//�豸��Ŀ�����¼�����
/*************************************************************************************/
void CPSDiscoveryDlg::OnNMDblclkListDev(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	int nItem = -1;

	if (pNMListView->iItem != -1)
	{
		
		nItem = m_list_dev.GetNextItem(nItem, LVNI_SELECTED);
		if (nItem == -1)
		{
			return;
		}
		pProDlg->m_stdev_node.id = nItem;
		CString strBuf;
		strBuf = m_list_dev.GetItemText(nItem, 1);
		pProDlg->m_stdev_node.Mac.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, 6);
		pProDlg->m_stdev_node.Name.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, 2);
		pProDlg->m_stdev_node.Ip.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, 3);
		pProDlg->m_stdev_node.Mask.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, 4);
		pProDlg->m_stdev_node.Gate.Format(_T("%s"), strBuf);
		pProDlg->DoModal();
		
		GetCurrentComboIf();
	}
	*pResult = 0;
}
/*************************************************************************************/
//��ȡ������Ϣ
/*************************************************************************************/
void CPSDiscoveryDlg::CPSDiscoveryInterfaceInit()
{
#pragma comment (lib,"iphlpapi.lib")
#pragma comment (lib,"ws2_32.lib")
	PIP_ADAPTER_ADDRESSES pAddresses = NULL;
	IP_ADAPTER_DNS_SERVER_ADDRESS *pDnServer = NULL;
	ULONG outBufLen = 0;
	DWORD dwRetVal = 0;
	int i = 0;
	char buf[1024] = { 0 };
	char tmpBuf[20] = { 0 };
	unsigned int uiInterfaceNum = 0;

	GetAdaptersAddresses(AF_UNSPEC, 0, NULL, pAddresses, &outBufLen);

	pAddresses = (IP_ADAPTER_ADDRESSES*)malloc(outBufLen);
	//ö����������
	if ((dwRetVal = GetAdaptersAddresses(AF_INET, GAA_FLAG_SKIP_ANYCAST, NULL, pAddresses, &outBufLen)) == NO_ERROR)
	{
		while (pAddresses)
		{
			/******************************************************************************
			*****�ڳ���ʼ����ͷ�ļ�:

			*****#include<WS2tcpip.h>
			*****���ڣ� inet_ntoa(addr2.sin_addr);
			*****����ȼ��滻Ϊ
			*****char sendBuf[20] = {'\0'};
			*****inet_ntop(AF_INET,(void*)&addr2.sin_addr,sendBuf,16);
			*****���ڣ� addr.sin_addr.S_un.S_addr=inet_addr("127.0.0.1");
			*****�ȼ��滻Ϊ�� inet_pton(AF_INET, "127.0.0.1", (void*)&addr.sin_addr.S_un.S_addr);
			******************************************************************************/
			PIP_ADAPTER_UNICAST_ADDRESS pUnicast = pAddresses->FirstUnicastAddress;
			if (pUnicast)
			{
				if (pUnicast->Address.lpSockaddr->sa_family == AF_INET)
				{
					sockaddr_in *sa_in = (sockaddr_in *)pUnicast->Address.lpSockaddr;
					inet_ntop(AF_INET, (void*)&(sa_in->sin_addr), tmpBuf, 16);
					//inet_pton(AF_INET, tmpBuf, &(stIfList[uiInterfaceNum].auiIp[i]));
					stIfList[uiInterfaceNum].auiIp[i] = tmpBuf;

					int ret = 0;
					CString cmpBuf;
					cmpBuf = tmpBuf;
					//���ػػ��ڲ���ʾ
					ret = StrCmpW(cmpBuf, _T("127.0.0.1"));
					if (!ret)
					{
						pAddresses = pAddresses->Next;
						continue;
					}
				}
			}
			//��ȡ����IP
			for (i = 0; pUnicast != NULL; i++)
			{
				if (pUnicast->Address.lpSockaddr->sa_family == AF_INET)
				{
					sockaddr_in *sa_in = (sockaddr_in *)pUnicast->Address.lpSockaddr;
					inet_ntop(AF_INET, (void*)&(sa_in->sin_addr), tmpBuf, 16);
					//inet_pton(AF_INET, tmpBuf, &(stIfList[uiInterfaceNum].auiIp[i]));
					stIfList[uiInterfaceNum].auiIp[i] = tmpBuf;
				}
				else if (pUnicast->Address.lpSockaddr->sa_family == AF_INET6)
				{
					//sockaddr_in6 *sa_in6 = (sockaddr_in6 *)pUnicast->Address.lpSockaddr;
					//printf("IPV6:%s\n",inet_ntoa((sa_in6->sin6_addr)); 
				}
				else
				{
					MessageBox(_T("get ip error"));
				}

				pUnicast = pUnicast->Next;

			}
			stIfList[uiInterfaceNum].uiIpAddrNum = i;

			/*Description*/
			(stIfList[uiInterfaceNum].aucDescription) = pAddresses->Description;
			//memcpy((stInterface[uiInterfaceNum].aucDescription), pAddresses->Description, strlen((char*)(pAddresses->Description)));

			/*Mac*/
			int j = 0;
			for (j = 0; j < 6; j++)
			{
				stIfList[uiInterfaceNum].aucMac[j] = pAddresses->PhysicalAddress[j];
			}
			//memcpy((stInterface[uiInterfaceNum].aucMac), pAddresses->PhysicalAddress, 6);

			/*Name*/
			(stIfList[uiInterfaceNum].aucName) = pAddresses->FriendlyName;
			//memcpy((stInterface[uiInterfaceNum].aucName), pAddresses->FriendlyName, strlen((char*)(pAddresses->FriendlyName)));

			stIfList[uiInterfaceNum].adapterName = pAddresses->AdapterName;

			pAddresses = pAddresses->Next;
			uiInterfaceNum++;
		}
		free(pAddresses);
	}
	m_iIfNum = uiInterfaceNum;

	//��combox���г���������
	for (int i = 0; i < m_iIfNum; i++)
	{
		CString str;
		str = stIfList[i].aucName + _T("   (") + stIfList[i].auiIp[0] + _T(")");
		m_comboBox.AddString(str);
	}
	//���õ�ǰ����
	m_comboBox.SetCurSel(0);
	//��ȡ������Ϣ
	GetCurrentComboIf();
}
/*************************************************************************************/
//������Ϣ
/*************************************************************************************/
BOOL CPSDiscoveryDlg::CPSDiscoveryIfDevInit()
{
	OnCbnSelchangeComboInterface();
	return true;
}
/*************************************************************************************/
//��ȡ������Ϣ
/*************************************************************************************/
void CPSDiscoveryDlg::GetCurrentComboIf()
{
	CString buf;
	int ret = 0;
	int i = 0;
	int devCount;
	devCount = 0;
	GetDlgItemText(IDC_COMBO_INTERFACE, buf);
	for (i = 0; i < m_iIfNum; i++)
	{
		CString str;
		str = stIfList[i].aucName + _T("   (") + stIfList[i].auiIp[0] + _T(")");
		ret = StrCmpW(buf, str);
		if (ret == 0)
		{
			break;
		}
	}
	pcap_freealldevs(g_pInetDevList);
	g_pInetDevCur = lixsniff_initCap(stIfList[i].adapterName, g_pInetDevList);
	if (g_pInetDevCur == NULL)
	{
		//MessageBox(_T("adapter == NULL"));
		exit(-1);
	}
	//����ǰ��������Ϣ���ݸ����ԶԻ���
	stCulIfDev = stIfList[i];
	memcpy(pProDlg->stCulIfDev.aucMac, &stCulIfDev.aucMac, sizeof(stCulIfDev.aucMac));
	pProDlg->stCulIfDev.adapterName.Format(_T("%s"), "");
	pProDlg->stCulIfDev.adapterName.Format(_T("%s"), stCulIfDev.adapterName);
	for (unsigned int j = 0; j < (stCulIfDev.uiIpAddrNum); j++)
	{
		pProDlg->stCulIfDev.auiIp[j].Format(_T("%s"), "");
		pProDlg->stCulIfDev.auiIp[j].Format(_T("%s"), stCulIfDev.auiIp[j]);
	}
	pProDlg->stCulIfDev.uiIpAddrNum = stCulIfDev.uiIpAddrNum;
}
/*************************************************************************************/
//�����л�
/*************************************************************************************/
void CPSDiscoveryDlg::OnCbnSelchangeComboInterface()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	GetCurrentComboIf();
}

void CPSDiscoveryDlg::childDlgtoMainDlg(CProDlg * pDlg)
{
	/*do nothing*/
}
/*************************************************************************************/
//��ʱ������
/*************************************************************************************/
void CPSDiscoveryDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	switch (nIDEvent)
	{
		case 1:
		{
			KillTimer(1);
			if (m_bRun)
			{
				m_bRun--;
				pProcessDlg->m_Process_ctrl.StepIt();//��ʾ����
				SetTimer(1, 300, NULL);
#if(0)
				if (m_bRun <= 2)
				{
					SetTimer(1, 500, NULL);
					g_flagCtrl = FALSE;
				}
				else
				{
					SetTimer(1, 300, NULL);
				}
#endif
			}
			else
			{
				m_bRun = 10;
				pProcessDlg->ClodeDlg(); 
				g_flagCtrl = FALSE;
			}
			break;
		}
		default:
			break;
	}
	CDialogEx::OnTimer(nIDEvent);
}
/*************************************************************************************/
//about �Ի���
/*************************************************************************************/
void CPSDiscoveryDlg::OnNemuAbout()
{
	// TODO: �ڴ�����������������
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}
/*************************************************************************************/
//about �Ի���ͼƬ��������
/*************************************************************************************/
void CAboutDlg::OnStnClickedPictrueCtrl()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	ShellExecute(NULL, _T("open"), _T("http://www.primestone.com.cn/"), NULL, NULL, SW_SHOWNORMAL);
}
/*************************************************************************************/
//about �Ի���ͼƬ��������״
/*************************************************************************************/
BOOL CAboutDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if (pWnd->GetDlgCtrlID() == IDC_PICTRUE_CTRL)
	{
		SetCursor(LoadCursor(NULL, IDC_HAND)); //IDC_SIZEWE
	}
	else
	{
		return CDialog::OnSetCursor(pWnd, nHitTest, message);
	}
	return TRUE;
}
/*************************************************************************************/
//�¼�����������δ�õ���ʱ����
/*************************************************************************************/
void CPSDiscoveryDlg::OnBnClickedButtonSearch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnMenuSearch();
}
/*************************************************************************************/
//list�е��Ҽ��˵�
/*************************************************************************************/
void CPSDiscoveryDlg::OnNMRClickListDev(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();
	int lang = pApp->GetLang();
	int ret = 0;
	int nItem = 0;
	unsigned char m_itemStatus = 0;
	PSDP_SIGNAL_STATUS *p = m_itemSignalStatus;
	//int m_listItemCnt = m_list_dev.GetItemCount();
	ret = CPSDiscoveryDevStateCheck(&nItem);
	

	while (p->item)
	{
		if (p->item == nItem + 1)
		{
			m_itemStatus = p->status;
			break;
		}
		p++;
	}

	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	if (pNMListView->iItem != -1)
	{
		DWORD dwPos = GetMessagePos();
		CPoint point(LOWORD(dwPos), HIWORD(dwPos));
		CMenu menu;
		VERIFY(menu.LoadMenu(IDR_MENU));
		CMenu* popup = menu.GetSubMenu(1);
		
		CCmdUI cmdUI;
		cmdUI.m_pOther = NULL;
		cmdUI.m_pMenu = popup;
		cmdUI.m_pSubMenu = NULL;

		UINT count = popup->GetMenuItemCount();
		cmdUI.m_nIndexMax = count;
		for (UINT i = 0; i<count; i++)
		{
			UINT nID = popup->GetMenuItemID(i);
			cmdUI.m_nID = nID;
			cmdUI.m_nIndex = i;
			if (i == 0)
			{
				if(m_itemStatus == 0x00 || m_itemStatus == DEV_COMMAND_SIGNAL_CLOSE)
				{
					if (lang == ENGLISH)
					{
						cmdUI.SetText(_T("Open signal(&O)"));

					}
					else
					{
						cmdUI.SetText(_T("���ź�(&O)"));
					}
				}
				else if (m_itemStatus == DEV_COMMAND_SIGNAL_OPEN)
				{
					if (lang == ENGLISH)
					{
						cmdUI.SetText(_T("Close signal(&C)"));

					}
					else
					{
						cmdUI.SetText(_T("�ر��ź�(&C)"));
					}
				}
			}
			//cmdUI.Enable(m_status);
		}
		
		ASSERT(popup != NULL);
		popup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);
	}
	*pResult = 0;
}
/*************************************************************************************/
//δ�õ���ʱ����
/*************************************************************************************/
void CPSDiscoveryDlg::resize()
{
	float fsp[2];
	POINT Newp; //��ȡ���ڶԻ���Ĵ�С
	CRect recta;
	GetClientRect(&recta); //ȡ�ͻ�����С  
	Newp.x = recta.right - recta.left;
	Newp.y = recta.bottom - recta.top;
	fsp[0] = (float)Newp.x / Old.x;
	fsp[1] = (float)Newp.y / Old.y;
	CRect Rect;
	int woc;
	CPoint OldTLPoint, TLPoint; //���Ͻ�
	CPoint OldBRPoint, BRPoint; //���½�
	int iID = 0;
	HWND hwndChild = ::GetWindow(m_hWnd, GW_CHILD); //�г����пؼ�  
	while (hwndChild)
	{
		iID = ::GetDlgCtrlID(hwndChild);
		if (iID == IDC_BUTTON_SEARCH || iID == IDC_COMBO_INTERFACE)
		{
			hwndChild = ::GetWindow(hwndChild, GW_HWNDNEXT);
			continue;
		}
		woc = ::GetDlgCtrlID(hwndChild);//ȡ��ID
		GetDlgItem(woc)->GetWindowRect(Rect);
		ScreenToClient(Rect);
		OldTLPoint = Rect.TopLeft();
		TLPoint.x = long(OldTLPoint.x*fsp[0]);
		TLPoint.y = long(OldTLPoint.y*fsp[1]);
		OldBRPoint = Rect.BottomRight();
		BRPoint.x = long(OldBRPoint.x *fsp[0]);
		if (iID == IDC_LIST_DEV)
		{
			BRPoint.y = long(OldBRPoint.y *fsp[1]);
		}
		else
		{
			BRPoint.y = long(OldBRPoint.y);
		}
		
		Rect.SetRect(TLPoint, BRPoint);
		GetDlgItem(woc)->MoveWindow(Rect, TRUE);
		hwndChild = ::GetWindow(hwndChild, GW_HWNDNEXT);
	}
	Old = Newp;
}
/*************************************************************************************/
//δ�õ���ʱ����
/*************************************************************************************/
void CPSDiscoveryDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);
	
#if 0//�ײ�״̬��
	//StatusBarInit();
	CString stime;
	//stime.Format(L"%s", time.Format(L"%y-%m-%d %H:%M:%S"));

	//����״̬��
	UINT array[2] = { 12301,12302 };
	m_Statusbar.DestroyWindow();
	m_Statusbar.Create(this);
	//m_Statusbar.Getcu
	m_Statusbar.SetIndicators(array, sizeof(array) / sizeof(UINT));

	//��ʾ״̬��
	CRect rect;
	GetWindowRect(rect);
	m_Statusbar.SetPaneInfo(0, array[0], 0, rect.Width() / 3);
	m_Statusbar.SetPaneInfo(1, array[1], 0, rect.Width() / 3 * 2);
	//m_Statusbar.SetPaneText(0, stime);
	stime.Format(L"%s%c%s", L"Copyright ", 0x40, L"2005 - 2013 �����к�ʯ����Ƽ����޹�˾ ��ICP��14093246��-2 ");
	m_Statusbar.SetPaneText(1, stime);
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);
#endif
	// TODO: �ڴ˴�������Ϣ�����������
	//resize();
	//UPDATE_EASYSIZE;
	/*
	CRect rect;    // ��ȡ�ؼ��仯ǰ��С   
	CWnd * pWnd;
	pWnd = GetDlgItem(IDC_LIST_DEV);      // ��ȡ�ؼ����  
	ScreenToClient(&rect); // ���ؼ���Сת��Ϊ�ڶԻ����е���������  
							// ��cx/m_rect.Width()Ϊ�Ի����ں���ı仯����   
	rect.left = rect.left * cx / m_rect.Width();  /// //�����ؼ���С   
	rect.right = rect.right * cx / m_rect.Width();
	rect.top = rect.top * cy / m_rect.Height();
	rect.bottom = rect.bottom * cy / m_rect.Height();
	pWnd->MoveWindow(rect); // ���ÿؼ���С   
	
	GetClientRect(&m_rect); // ���仯��ĶԻ����С��Ϊ�ɴ�С 

	//CDialog::OnSize(nType, cx, cy);
	// TODO: Add your message handler code here
	*/
	
}
/*************************************************************************************/
//δ�õ���ʱ����
/*************************************************************************************/
void CPSDiscoveryDlg::OnSizing(UINT fwSide, LPRECT pRect)
{
	CDialog::OnSizing(fwSide, pRect);
	//EASYSIZE_MINSIZE(280, 250, fwSide, pRect);
}
/*************************************************************************************/
//judge the status of signal when menu popuped
/*************************************************************************************/
void CPSDiscoveryDlg::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu)
{
	CDialogEx::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();
	int lang = pApp->GetLang();
	// TODO: �ڴ˴�������Ϣ�����������
	int ret = 0;
	int nItem = 0;
	unsigned char m_itemStatus = 0;
	PSDP_SIGNAL_STATUS *p = m_itemSignalStatus;
	int m_listItemCnt = m_list_dev.GetItemCount();
	ret = CPSDiscoveryDevStateCheck(&nItem);

	while (p->item)
	{
		if (p->item == nItem + 1)
		{
			m_itemStatus = p->status;
			break;
		}
		p++;
	}

	BOOL m_status = m_listItemCnt ? TRUE : FALSE;
	if (nIndex == 1)
	{
		if (!bSysMenu && pPopupMenu)
		{
			CCmdUI cmdUI;
			cmdUI.m_pOther = NULL;
			cmdUI.m_pMenu = pPopupMenu;
			cmdUI.m_pSubMenu = NULL;

			UINT count = pPopupMenu->GetMenuItemCount();
			cmdUI.m_nIndexMax = count;
			for (UINT i = 0; i<count; i++)
			{
				UINT nID = pPopupMenu->GetMenuItemID(i);
				cmdUI.m_nID = nID;
				cmdUI.m_nIndex = i;
				if (i == 0)
				{
					if (m_itemStatus == 0x00 || m_itemStatus == DEV_COMMAND_SIGNAL_CLOSE)
					{
						if (lang == ENGLISH)
						{
							cmdUI.SetText(_T("Open signal(&O)"));

						}
						else
						{
							cmdUI.SetText(_T("���ź�(&O)"));
						}
					}
					else if (m_itemStatus == DEV_COMMAND_SIGNAL_OPEN)
					{
						if (lang == ENGLISH)
						{
							cmdUI.SetText(_T("Close signal(&C)"));

						}
						else
						{
							cmdUI.SetText(_T("�ر��ź�(&C)"));
						}
					}
				}
				//cmdUI.Enable(m_status);
			//}
				
				cmdUI.Enable(m_status);
			}
		}
	}
}

/*************************************************************************************/
//Limit the minimum dialog
/*************************************************************************************/
void CPSDiscoveryDlg::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	//������С�߶������,�����Ҫ�Ļ�
	lpMMI->ptMinTrackSize.x = 867;
	lpMMI->ptMinTrackSize.y = 640;
	//�������߶������,�����Ҫ�Ļ�
	//lpMMI->ptMaxTrackSize.x = 1366;
	//lpMMI->ptMaxTrackSize.y = 768;
	CDialogEx::OnGetMinMaxInfo(lpMMI);
}
/*************************************************************************************/
//Initialization of the docking toolbar
/*************************************************************************************/
void CPSDiscoveryDlg::PSDiscoveryToolBarInit()
{
	m_ToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE
		| CBRS_TOP //��ʼͣ���ڿͻ�������
		| CBRS_GRIPPER //�����һ������
		| CBRS_TOOLTIPS //����������ʾ
		| CBRS_FLYBY //������Ϣ�ı�
		| CBRS_SIZE_DYNAMIC //��̬�ı��С
		//| CBRS_BORDER_TOP //�ڹ�����������ʾ�߿�
		//| CBRS_ALIGN_ANY

	);
	CImageList m_ImageList;
	//����ͼ��
	m_ImageList.Create(32, 32, ILC_COLOR32 | ILC_MASK, 2, 2); //������������2,2������Ҫ�����ָ��

	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON1));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON6));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON5));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON2));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON3));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON7));
	m_ImageList.Add(AfxGetApp()->LoadIcon(IDI_ICON4));

	m_ToolBar.GetToolBarCtrl().SetImageList(&m_ImageList);
	m_ImageList.Detach();
	m_ToolBar.SetButtons(NULL, 7); //��7����ť
								   // ��������ÿ�����߰�ť���֣����ú�ÿ��ͼ���������ʾ��Ӧ�����֡�Ҳ���Բ�����
	m_ToolBar.SetButtonInfo(0, ID_SEARCH, TBSTYLE_BUTTON, 0);
	//m_ToolBar.SetButtonText(0, L"SEARCH");//����
	
	m_ToolBar.SetButtonInfo(1, ID_SIGNAL, TBSTYLE_BUTTON, 1);
	//m_ToolBar.SetButtonText(1, L"SIGNAL");//�ź�

	m_ToolBar.SetButtonInfo(2, ID_PROPERTY, TBSTYLE_BUTTON, 2);
	//m_ToolBar.SetButtonText(2, L"PROPERTY");//����

	m_ToolBar.SetButtonInfo(3, ID_WEB, TBSTYLE_BUTTON, 3);
	//m_ToolBar.SetButtonText(3, L"WEB");//��½Web

	m_ToolBar.SetButtonInfo(4, ID_PING, TBSTYLE_BUTTON, 4);
	//m_ToolBar.SetButtonText(4, L"PING");//Ping

	m_ToolBar.SetButtonInfo(5, ID_TELNET, TBSTYLE_BUTTON, 5);
	//m_ToolBar.SetButtonText(5, L"TELNET");//Telnet

	m_ToolBar.SetButtonInfo(6, ID_PARA, TBSTYLE_BUTTON, 6);

	m_ToolBar.SetSizes(CSize(45, 45), CSize(32, 32)); //���ð�ť�Ĵ�С��ע�������ť��СҪ��ͼ���б���ͼ��Ĵ�Сһ��(32,32)
													  //CSize(51,51)���ð�ť��С�� CSize(32,32)���ð�ť��ͼ���С,
													  //ע�⣬��һ��CSize�еĲ�������ȵڶ���CSize�еĲ����󣬷ֱ������7��6����������
													  //(CSize(cx1,cy1), CSize(cx2,cy2));cx1-cx2>=7,cy1-cy2>=6

	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0); //��Ҫ���˵��ô˺��������򹤾�������ʾ��
}
/*************************************************************************************/
//operation of toolbar
/*************************************************************************************/
void CPSDiscoveryDlg::ToolBarOnSearch()
{
	// TODO: �ڴ�����������������
	//MessageBox(L"ToolBarOnSearch");
	OnMenuSearch();
}

void CPSDiscoveryDlg::ToolBarOnSignal()
{
	// TODO: �ڴ�����������������
	//MessageBox(L"ToolBarOnSignal");
	OnMenuSignalOpt();
}

void CPSDiscoveryDlg::ToolBarOnProperty()
{
	// TODO: �ڴ�����������������
	//MessageBox(L"ToolBarOnProperty");
	OnMenuProperty();
}

void CPSDiscoveryDlg::ToolBarOnWeb()
{
	// TODO: �ڴ�����������������
	//MessageBox(L"ToolBarOnWeb");
	OnMenuWeb();
}

void CPSDiscoveryDlg::ToolBarOnPing()
{
	// TODO: �ڴ�����������������
	//MessageBox(L"ToolBarOnPing");
	OnMenuPing();
}

void CPSDiscoveryDlg::ToolBarOnTelnet()
{
	// TODO: �ڴ�����������������
	//MessageBox(L"ToolBarOnTelnet");
	OnMenuTelnet();
}

void CPSDiscoveryDlg::OnPara()
{
	// TODO: �ڴ�����������������
	OnMenuPara();
}
/*************************************************************************************/
//��ʾ��Ϣ
/*************************************************************************************/
BOOL CPSDiscoveryDlg::OnToolTipsNotify(UINT id, NMHDR * pNMHDR, LRESULT * pResult)
{
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();
	int lang = pApp->GetLang();
	TOOLTIPTEXT *pT = (TOOLTIPTEXT*)pNMHDR;
	UINT nId = pNMHDR->idFrom;
	
	if (lang == ENGLISH)
	{
		switch (nId)
		{
		case ID_SEARCH:
		{
			pT->lpszText = _T("Discovery");
			break;
		}
		case ID_SIGNAL:
		{
			pT->lpszText = _T("Signal");
			break;
		}
		case ID_PROPERTY:
		{
			pT->lpszText = _T("Device");
			break;
		}
		case ID_WEB:
		{
			pT->lpszText = _T("Log in WEB");
			break;
		}
		case ID_PING:
		{
			pT->lpszText = _T("Ping");
			break;
		}
		case ID_TELNET:
		{
			pT->lpszText = _T("Telnet");
			break;
		}
		case ID_PARA:
		{
			pT->lpszText = _T("Setting");
			break;
		}
		default:
			break;
		}
	}
	else
	{
		switch (nId)
		{
		case ID_SEARCH:
		{
			pT->lpszText = _T("����");
			break;
		}
		case ID_SIGNAL:
		{
			pT->lpszText = _T("�����ź�");
			break;
		}
		case ID_PROPERTY:
		{
			pT->lpszText = _T("�豸��Ϣ");
			break;
		}
		case ID_WEB:
		{
			pT->lpszText = _T("��¼WEB");
			break;
		}
		case ID_PING:
		{
			pT->lpszText = _T("Ping");
			break;
		}
		case ID_TELNET:
		{
			pT->lpszText = _T("Telnet");
			break;
		}
		case ID_PARA:
		{
			pT->lpszText = _T("����");
			break;
		}
		default:
			break;
		}
	}
	return 0;
}
/*************************************************************************************/
//���λس���ESC
/*************************************************************************************/
BOOL CPSDiscoveryDlg::PreTranslateMessage(MSG* pMsg)	// << ADD THIS
{
	// Reroute message to the miniframe wnd
	#ifdef _TOOLBAR_FLOATING_
	if (m_stbar.m_hWnd)
		m_stbar.PreTranslate(pMsg);
	#endif
	if (pMsg->message == WM_KEYDOWN) 
	{
		switch (pMsg->wParam) 
		{
			//case VK_RETURN: //�س�
			//{
			//	return TRUE;
			//}
			case VK_ESCAPE: //ESC 
			{
				return TRUE;
			}
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CPSDiscoveryDlg::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	int ret = 0;
	int nItem = -1;
	ret = CPSDiscoveryDevStateCheck(&nItem);
	if (ret)
	{
		pProDlg->m_stdev_node.id = nItem;
		CString strBuf;
		strBuf = m_list_dev.GetItemText(nItem, 1);
		pProDlg->m_stdev_node.Mac.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, 6);
		pProDlg->m_stdev_node.Name.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, 2);
		pProDlg->m_stdev_node.Ip.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, 3);
		pProDlg->m_stdev_node.Mask.Format(_T("%s"), strBuf);
		strBuf = m_list_dev.GetItemText(nItem, 4);
		pProDlg->m_stdev_node.Gate.Format(_T("%s"), strBuf);
		pProDlg->DoModal();

		GetCurrentComboIf();
	}
	//CDialogEx::OnOK();
}
/*************************************************************************************/
//��������DLL
/*************************************************************************************/
void CPSDiscoveryDlg::OnLanguageChs()
{
	// TODO: �ڴ�����������������
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();

	//int old_Lang = pApp->GetLang();
	int new_Lang = CHINESE;
	//if (old_Lang == ENGLISH)
	//	new_Lang = CHINESE;
	//else
	//	new_Lang = ENGLISH;

	CFile file;
	file.Open(_T("Language.ini"), CFile::modeWrite | CFile::modeCreate | CFile::typeBinary);
	file.Write(&new_Lang, sizeof(new_Lang));
	file.Close();

	//���ٵ�ǰ����    
	pApp->m_pMainWnd = NULL;
	this->DestroyWindow();

	//�����µĴ���
	pApp->LoadLanguage();
	pApp->OpenWindow();
}
/*************************************************************************************/
//��������DLL
/*************************************************************************************/
void CPSDiscoveryDlg::OnLanguageEnglish()
{
	// TODO: �ڴ�����������������
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();

	//int old_Lang = pApp->GetLang();
	int new_Lang = ENGLISH;
	//if (old_Lang == ENGLISH)
	//	new_Lang = CHINESE;
	//else
	//	new_Lang = ENGLISH;

	CFile file;
	file.Open(_T("Language.ini"), CFile::modeWrite | CFile::modeCreate | CFile::typeBinary);
	file.Write(&new_Lang, sizeof(new_Lang));
	file.Close();

	//���ٵ�ǰ����    
	pApp->m_pMainWnd = NULL;
	this->DestroyWindow();

	//�����µĴ���
	pApp->LoadLanguage();
	pApp->OpenWindow();
}
/*************************************************************************************/
//���������豸����ϢΪ.xls�ļ�
/*************************************************************************************/
void CPSDiscoveryDlg::OnfileExport()
{
	CPSDiscoveryApp*pApp = (CPSDiscoveryApp*)AfxGetApp();
	int lang = pApp->GetLang();
	
	CTime time = CTime::GetCurrentTime();//��ȡ��ǰϵͳʱ��
	CString strRptTime = _T("PSDiscovery-") + time.Format(_T("%Y%m%d%H%M%S"));
	CString fileName = strRptTime + _T(".xls");//Ĭ���ļ���
	CString strFile;
	CFileDialog    dlgFile(FALSE, NULL, fileName, OFN_HIDEREADONLY, _T("Describe Files (*.xls)|*.cfg|All Files (*.*)|*.*||"), NULL);
	
	if (dlgFile.DoModal() == IDOK)//�ļ�����Ի���
	{
		strFile = dlgFile.GetPathName();
		// ʵ�ִ���
		const char *Buf[2] =
		{
			"ID\tMAC��ַ\tIP��ַ\t��������\tȱʡ����\t��Ʒ\t����\r\n",
			"ID\tMAC\tIP\tMask\tGateway\tProduct\tName\r\n"
		};
		char *pbuf = NULL;
		CFile file(strFile, CFile::modeCreate | CFile::modeReadWrite | CFile::shareExclusive);
		int loop = 0;
		int listCount = 0;
		int len = 0;

		if (lang == CHINESE)
		{
			file.Write(Buf[0], strlen(Buf[0]));
		}
		else
		{
			file.Write(Buf[1], strlen(Buf[1]));
		}

		listCount = m_list_dev.GetItemCount();
		if (listCount > 0)
		{
			for (loop = 0; loop < listCount; loop++)
			{
				CString msg;

				msg = m_list_dev.GetItemText(loop, LIST_DEV_ID) + _T("\t")
					+ m_list_dev.GetItemText(loop, LIST_DEV_MAC) + _T("\t")
					+ m_list_dev.GetItemText(loop, LIST_DEV_IP) + _T("\t")
					+ m_list_dev.GetItemText(loop, LIST_DEV_MASK) + _T("\t")
					+ m_list_dev.GetItemText(loop, LIST_DEV_GATE) + _T("\t")
					+ m_list_dev.GetItemText(loop, LIST_DEV_PROTYPE) + _T("\t")
					+ m_list_dev.GetItemText(loop, LIST_DEV_NAME) + _T("\t")
					+ _T("\r\n");

				USES_CONVERSION;//CStringתchar*
				pbuf = T2A(msg);//CStringתchar*
				len = msg.GetLength();
				msg.ReleaseBuffer();
				file.Write(pbuf, len);
			}
		}
		Buf[0] = NULL;
		Buf[1] = NULL;
		pbuf = NULL;
		file.Close();
	}
}